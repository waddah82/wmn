WMN POS search / camera overlay
================================

Extract this zip into the SAME folder that already contains:
  wmn/public/
  wmn/wmn/page/wmn_pos/

On a typical bench that folder is:
  /home/frappe/frappe-bench/apps/wmn

Then run:
  bench --site YOUR_SITE migrate
  bench build --app wmn
  bench --site YOUR_SITE clear-cache

Hard-refresh the POS page (Ctrl+Shift+R).

This pack is only the latest search/camera/nav files, including the rebuilt
wmn_pos.js bundle. It does not include the rest of the branch.

Files:
  wmn/public/css/wmn_pos.css
  wmn/public/js/features/mobile_barcode_scanner/mobile_barcode_scanner.common.js
  wmn/public/js/features/mobile_barcode_scanner/tests/mobile_barcode_scanner.node.js
  wmn/setup/pos_profile_settings.py
  wmn/wmn/doctype/wmn_pos_profile_settings/wmn_pos_profile_settings.json
  wmn/wmn/page/wmn_pos/wmn/components/item_selector/class.js
  wmn/wmn/page/wmn_pos/wmn/components/item_selector/methods.js
  wmn/wmn/page/wmn_pos/wmn/support/features/barcode_scan_quantity/barcode_scan_quantity.ui.js
  wmn/wmn/page/wmn_pos/wmn/support/features/barcode_scan_quantity/tests/barcode_scan_quantity.ui.node.js
  wmn/wmn/page/wmn_pos/wmn/support/features/ui_preferences/ui_preferences.common.js
  wmn/wmn/page/wmn_pos/wmn/support/services/settings/pos_profile_settings.js
  wmn/wmn/page/wmn_pos/wmn/support/ui/dialog_manager.js
  wmn/wmn/page/wmn_pos/wmn_pos.js
